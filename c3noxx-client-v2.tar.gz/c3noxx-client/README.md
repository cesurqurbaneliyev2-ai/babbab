# C3noxx Client — Quraşdırma Təlimatı

**Azərbaycan Minecraft** üçün ultra-performanslı Fabric client modu.  
Nitro estetikası · Sodium + Lithium + FerriteCore daxili · Super Optimization rejimi

---

## 1. Tələblər

| Proqram | Versiya |
|---------|---------|
| Java (JDK) | 21+ |
| Minecraft | 1.21.1 |
| Fabric Loader | 0.15.11+ |
| Gradle | 8.x (wrapper avtomatik yükləyir) |
| IDE | VS Code, IntelliJ IDEA, və ya Replit |

---

## 2. Quraşdırma addımları

### 2a. Repozitoriyanı açın

```bash
# VS Code / Terminal:
cd c3noxx-client
```

### 2b. Gradle Wrapper yükləyin (yalnız bir dəfə)

```bash
gradle wrapper --gradle-version 8.8
```

> **Replit istifadəçiləri:** Replit Shell-i açın, layihə qovluğuna keçin və aşağıdakı əmrləri işlədin.

### 2c. Modu yığın (build edin)

```bash
./gradlew build
```

Windows üçün:
```cmd
gradlew.bat build
```

Nəticə fayl: `build/libs/c3noxx-client-1.0.0.jar`

---

## 3. Tövsiyə olunan JVM Arqumentləri

Minecraft Launcher → **JVM Arguments** sahəsinə əlavə edin:

```
-Xmx4G -Xms2G
-XX:+UseG1GC
-XX:G1HeapRegionSize=32m
-XX:+ParallelRefProcEnabled
-XX:MaxGCPauseMillis=200
-XX:+UnlockExperimentalVMOptions
-XX:+DisableExplicitGC
-XX:+AlwaysPreTouch
-XX:G1NewSizePercent=30
-XX:G1MaxNewSizePercent=40
-XX:G1MixedGCLiveThresholdPercent=90
-XX:G1RSetUpdatingPauseTimePercent=5
-XX:SurvivorRatio=32
-XX:+PerfDisableSharedMem
-XX:MaxTenuringThreshold=1
```

> **Qeyd:** `-Xmx` dəyərini sisteminizin RAM-ına uyğun dəyişin (8 GB RAM üçün `-Xmx6G` tövsiyə edilir).

---

## 4. FPS Optimallaşdırma Effekti

| Vəziyyət | Əvvəl | Sonra (təxmini) |
|----------|-------|-----------------|
| Aşağı sistem (4 GB RAM, intel HD) | ~40–60 FPS | ~150–250 FPS |
| Orta sistem (8 GB RAM, GTX 1060) | ~80–120 FPS | ~300–450 FPS |
| Yüksək sistem (16+ GB, RTX) | ~200+ FPS | ~500+ FPS |

> Sodium render pipeline-ı, Lithium logic optim., FerriteCore yaddaş azaldılması birlikdə işləyir.

---

## 5. Fayl Strukturu

```
c3noxx-client/
├── build.gradle                         ← Layihə qurulumu, dependency-lər
├── gradle.properties                    ← Versiyalar, JVM parametrləri
├── settings.gradle                      ← Layihə adı
└── src/main/
    ├── java/com/c3noxx/client/
    │   ├── C3noxxClient.java            ← Ana giriş nöqtəsi (ClientEntrypoint)
    │   ├── config/
    │   │   └── C3noxxConfig.java        ← JSON konfiqurasiya (config/ qovluğunda saxlanır)
    │   ├── gui/
    │   │   ├── C3noxxMainMenuScreen.java   ← Nitro ana menyu (qara + neon bənövşəyi)
    │   │   └── SuperOptimizationScreen.java ← Gizli ayarlar ekranı
    │   └── mixin/
    │       └── TitleScreenMixin.java    ← TitleScreen-i C3noxx ekranı ilə əvəz edir
    └── resources/
        ├── fabric.mod.json              ← Mod metadata, entrypoint qeydiyyatı
        ├── c3noxx-client.mixins.json   ← Mixin konfiqurasiyası
        └── assets/c3noxx-client/lang/
            ├── az_az.json              ← Azərbaycan dili
            └── en_us.json              ← İngilis dili (fallback)
```

---

## 6. Mixin izahı — TitleScreenMixin

```java
@Mixin(TitleScreen.class)
public class TitleScreenMixin {

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void c3noxx$replaceTitleScreen(CallbackInfo ci) {
        // Orijinal TitleScreen açılmadan əvvəl C3noxx ekranını göstər
        MinecraftClient.getInstance().setScreen(new C3noxxMainMenuScreen());
        ci.cancel(); // Standart init dayandırılır
    }
}
```

**Necə işləyir:**
1. Minecraft `TitleScreen#init()` çağıranda Mixin devreye girir
2. `@At("HEAD")` — metodun ən əvvəlindən tutulur
3. `cancellable = true` + `ci.cancel()` — standart GUI əvəz edilir
4. `C3noxxMainMenuScreen` Nitro interfeysi ilə açılır

---

## 7. Konfiqurasiya faylı

Oyun işə salındıqdan sonra `.minecraft/config/c3noxx-client.json` yaradılır:

```json
{
  "mainMenuTitle": "Azərbaycan Minecraft",
  "showNitroLogo": true,
  "enableBackgroundAnimation": true,
  "superOptimizationEnabled": true,
  "renderDistance": 8,
  "entityRenderLimit": 128,
  "chunkLoadThreads": 4,
  "simulationDistance": 6,
  "disableIdleAnimations": true,
  "skipHiddenEntityRendering": true,
  "aggressiveMemoryOptimization": true
}
```

---

## 8. Lisenziya

MIT © C3noxx Team
