package com.c3noxx.client.config;

import com.c3noxx.client.C3noxxClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * C3noxx Client — Konfiqurasiya Sinifi
 *
 * Faylı: config/c3noxx-client.json
 *
 * Bütün parametrlər buradan oxunur/yazılır.
 * Super Optimization rejiminin bütün parametrləri daxildir.
 */
public class C3noxxConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String CONFIG_FILE = "c3noxx-client.json";

    // ─── UI Parametrləri ─────────────────────────────────────────────────────
    /** Ana menyu başlığı */
    private String mainMenuTitle = "Azərbaycan Minecraft";

    /** Nitro loqonu göstər/gizlə */
    private boolean showNitroLogo = true;

    /** Fon animasiyasını aktiv et */
    private boolean enableBackgroundAnimation = true;

    // ─── Performans Parametrləri ──────────────────────────────────────────────
    /** Super Optimization rejimi */
    private boolean superOptimizationEnabled = true;

    /** Render məsafəsi (chunk) — SO rejimində 6-8 tövsiyə olunur */
    private int renderDistance = 8;

    /** Entity render həddi */
    private int entityRenderLimit = 128;

    /** Chunk yükləmə iş parçası sayı */
    private int chunkLoadThreads = 4;

    /** Simulation məsafəsi */
    private int simulationDistance = 6;

    /** Boş animasiyaları deaktiv et (FPS qazanımı ~15%) */
    private boolean disableIdleAnimations = true;

    /** Gizli entities-i render etmə (FPS qazanımı ~20%) */
    private boolean skipHiddenEntityRendering = true;

    /** Yaddaş istifadəsini azalt (FerriteCore ilə birlikdə) */
    private boolean aggressiveMemoryOptimization = true;

    // ─── JVM Arqumentləri (məlumat üçün) ─────────────────────────────────────
    /** Bu arqumentlər istifadəçi JVM start script-inə əlavə etməlidir */
    private String recommendedJvmArgs =
            "-Xmx4G -Xms2G " +
            "-XX:+UseG1GC " +
            "-XX:G1HeapRegionSize=32m " +
            "-XX:+ParallelRefProcEnabled " +
            "-XX:MaxGCPauseMillis=200 " +
            "-XX:+UnlockExperimentalVMOptions " +
            "-XX:+DisableExplicitGC " +
            "-XX:+AlwaysPreTouch " +
            "-XX:G1NewSizePercent=30 " +
            "-XX:G1MaxNewSizePercent=40 " +
            "-XX:G1MixedGCLiveThresholdPercent=90 " +
            "-XX:G1RSetUpdatingPauseTimePercent=5 " +
            "-XX:SurvivorRatio=32 " +
            "-XX:+PerfDisableSharedMem " +
            "-XX:MaxTenuringThreshold=1 " +
            "-Dfml.ignorePatchDiscrepancies=true " +
            "-Dfml.ignoreInvalidMinecraftCertificates=true " +
            "-Dorg.lwjgl.util.Debug=false " +
            "-Dorg.lwjgl.opengl.Display.allowSoftwareOpenGL=true";

    // ─── Statik metodlar ──────────────────────────────────────────────────────

    public static C3noxxConfig loadOrCreate() {
        Path configPath = FabricLoader.getInstance()
                .getConfigDir()
                .resolve(CONFIG_FILE);

        if (Files.exists(configPath)) {
            try (Reader reader = Files.newBufferedReader(configPath)) {
                C3noxxConfig loaded = GSON.fromJson(reader, C3noxxConfig.class);
                C3noxxClient.LOGGER.info("[C3noxx] Konfiqurasiya yükləndi: {}", configPath);
                return loaded;
            } catch (IOException e) {
                C3noxxClient.LOGGER.warn("[C3noxx] Konfiqurasiya oxuna bilmədi, standartlar istifadə edilir.", e);
            }
        }

        // Standart konfiqurasiya yaz
        C3noxxConfig defaults = new C3noxxConfig();
        defaults.save();
        C3noxxClient.LOGGER.info("[C3noxx] Standart konfiqurasiya yaradıldı: {}", configPath);
        return defaults;
    }

    public void save() {
        Path configPath = FabricLoader.getInstance()
                .getConfigDir()
                .resolve(CONFIG_FILE);
        try (Writer writer = Files.newBufferedWriter(configPath)) {
            GSON.toJson(this, writer);
        } catch (IOException e) {
            C3noxxClient.LOGGER.error("[C3noxx] Konfiqurasiya saxlanıla bilmədi!", e);
        }
    }

    // ─── Getters / Setters ───────────────────────────────────────────────────

    public String getMainMenuTitle() { return mainMenuTitle; }
    public void setMainMenuTitle(String v) { this.mainMenuTitle = v; }

    public boolean isShowNitroLogo() { return showNitroLogo; }
    public void setShowNitroLogo(boolean v) { this.showNitroLogo = v; }

    public boolean isEnableBackgroundAnimation() { return enableBackgroundAnimation; }
    public void setEnableBackgroundAnimation(boolean v) { this.enableBackgroundAnimation = v; }

    public boolean isSuperOptimizationEnabled() { return superOptimizationEnabled; }
    public void setSuperOptimizationEnabled(boolean v) { this.superOptimizationEnabled = v; }

    public int getRenderDistance() { return renderDistance; }
    public void setRenderDistance(int v) { this.renderDistance = Math.max(2, Math.min(32, v)); }

    public int getEntityRenderLimit() { return entityRenderLimit; }
    public void setEntityRenderLimit(int v) { this.entityRenderLimit = v; }

    public int getChunkLoadThreads() { return chunkLoadThreads; }
    public void setChunkLoadThreads(int v) { this.chunkLoadThreads = Math.max(1, v); }

    public int getSimulationDistance() { return simulationDistance; }
    public void setSimulationDistance(int v) { this.simulationDistance = v; }

    public boolean isDisableIdleAnimations() { return disableIdleAnimations; }
    public void setDisableIdleAnimations(boolean v) { this.disableIdleAnimations = v; }

    public boolean isSkipHiddenEntityRendering() { return skipHiddenEntityRendering; }
    public void setSkipHiddenEntityRendering(boolean v) { this.skipHiddenEntityRendering = v; }

    public boolean isAggressiveMemoryOptimization() { return aggressiveMemoryOptimization; }
    public void setAggressiveMemoryOptimization(boolean v) { this.aggressiveMemoryOptimization = v; }

    public String getRecommendedJvmArgs() { return recommendedJvmArgs; }
}
