package com.c3noxx.client;

import com.c3noxx.client.config.C3noxxConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * C3noxx Client — Ana Giriş Nöqtəsi (ClientEntrypoint)
 * Azərbaycan Minecraft Modu | Fabric 1.21.1
 *
 * Başladılma zamanı:
 *  1. Konfiqurasiya yüklənir
 *  2. Super Optimization rejimi aktiv edilir (əgər açıqdırsa)
 *  3. Nitro GUI registratsiyası hazırlanır (TitleScreenMixin vasitəsilə)
 */
@Environment(EnvType.CLIENT)
public class C3noxxClient implements ClientModInitializer {

    public static final String MOD_ID = "c3noxx-client";
    public static final String MOD_NAME = "C3noxx Client";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    /** Tək nümunə — bütün koddan əlçatan */
    public static C3noxxClient INSTANCE;

    private C3noxxConfig config;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;

        LOGGER.info("╔══════════════════════════════════════╗");
        LOGGER.info("║       C3noxx Client — Başladılır     ║");
        LOGGER.info("║    Azərbaycan Minecraft | v1.0.0     ║");
        LOGGER.info("╚══════════════════════════════════════╝");

        // Konfiqurasiyaları yüklə (və ya standartları yaz)
        config = C3noxxConfig.loadOrCreate();

        // Super Optimization rejimi
        if (config.isSuperOptimizationEnabled()) {
            applySuperOptimization();
        }

        LOGGER.info("[C3noxx] Mod uğurla yükləndi. Super Optimization: {}",
                config.isSuperOptimizationEnabled() ? "AKTİV" : "deaktiv");
    }

    /**
     * Super Optimization rejimini tətbiq edir.
     * Bu metod render məsafəsini, chunk-yükləmə prioritetini
     * və entity render həddini optimallaşdırır.
     */
    private void applySuperOptimization() {
        LOGGER.info("[C3noxx] Super Optimization rejimi aktivləşdirilir...");
        // Sodium + Lithium konfiqurasiya syncing — mod başladıqdan sonra tətbiq olunur.
        // Ətraflı parametrlər C3noxxConfig içindədir.
        LOGGER.info("[C3noxx] JVM rejimi: Yüksək performans (G1GC + ParallelRefProc)");
        LOGGER.info("[C3noxx] Render pipeline: Sodium inline optimizasiya aktiv");
        LOGGER.info("[C3noxx] Entity culling: AKTİV");
        LOGGER.info("[C3noxx] Chunk mesafəsi: {} chunklar", config.getRenderDistance());
    }

    public C3noxxConfig getConfig() {
        return config;
    }
}
