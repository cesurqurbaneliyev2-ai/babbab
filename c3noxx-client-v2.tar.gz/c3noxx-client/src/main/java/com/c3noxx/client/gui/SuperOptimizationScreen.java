package com.c3noxx.client.gui;

import com.c3noxx.client.C3noxxClient;
import com.c3noxx.client.config.C3noxxConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/**
 * Super Optimizasiya Gizli Ayarlar Menyusu
 *
 * Bu ekran yalnız C3noxx ana menyusundan əlçatandır.
 * Bütün performans parametrlərini vizual şəkildə idarə etməyə imkan verir.
 *
 * Parametrlər:
 *  - Super Optimization rejimi (açıq/qapalı)
 *  - Render məsafəsi (2–32 chunk)
 *  - Entity render həddi
 *  - Chunk yüklənmə axını sayı
 *  - Boş animasiyalar
 *  - Gizli Entity rendering
 *  - Aqressiv yaddaş optimizasiyası
 *  - Tövsiyə olunan JVM argumanları (məlumat)
 */
public class SuperOptimizationScreen extends Screen {

    // ─── Nitro rənglər ──────────────────────────────────────────────────────
    private static final int COLOR_BG           = 0xFF080012;
    private static final int COLOR_PANEL        = 0xCC110020;
    private static final int COLOR_NEON_PURPLE  = 0xFFAA00FF;
    private static final int COLOR_NEON_BLUE    = 0xFF0088FF;
    private static final int COLOR_WHITE        = 0xFFFFFFFF;
    private static final int COLOR_LABEL        = 0xFFCCAAFF;
    private static final int COLOR_WARNING      = 0xFFFFAA00;
    private static final int COLOR_SUCCESS      = 0xFF00FF88;

    private final Screen parent;
    private final C3noxxConfig config;

    // Anlıq UI dəyərləri (saxla düyməsindən əvvəl)
    private boolean tmpSuperOpt;
    private int     tmpRenderDist;
    private int     tmpEntityLimit;
    private int     tmpChunkThreads;
    private int     tmpSimDist;
    private boolean tmpDisableIdleAnim;
    private boolean tmpSkipHidden;
    private boolean tmpAggressiveMem;

    // Sürüşdürücülər
    private RenderDistanceSlider renderDistSlider;

    public SuperOptimizationScreen(Screen parent) {
        super(Text.literal("C3noxx — Super Optimizasiya"));
        this.parent = parent;
        this.config = C3noxxClient.INSTANCE.getConfig();

        // Cari konfiqurasiyadan anlıq dəyərləri götür
        this.tmpSuperOpt        = config.isSuperOptimizationEnabled();
        this.tmpRenderDist      = config.getRenderDistance();
        this.tmpEntityLimit     = config.getEntityRenderLimit();
        this.tmpChunkThreads    = config.getChunkLoadThreads();
        this.tmpSimDist         = config.getSimulationDistance();
        this.tmpDisableIdleAnim = config.isDisableIdleAnimations();
        this.tmpSkipHidden      = config.isSkipHiddenEntityRendering();
        this.tmpAggressiveMem   = config.isAggressiveMemoryOptimization();
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = 60;
        int bw = 220;
        int bh = 20;
        int gap = 26;

        // ── Super Optimization toggle ────────────────────────────────────────
        addSuperOptButton(cx, y, bw, bh);
        y += gap;

        // ── Render məsafəsi slider ───────────────────────────────────────────
        renderDistSlider = new RenderDistanceSlider(cx - bw / 2, y, bw, bh, tmpRenderDist);
        this.addDrawableChild(renderDistSlider);
        y += gap;

        // ── Simulation məsafəsi ──────────────────────────────────────────────
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Simulasiya məsafəsi: " + tmpSimDist + " chunk"),
                btn -> {
                    tmpSimDist = (tmpSimDist % 32) + 2;
                    btn.setMessage(Text.literal("Simulasiya məsafəsi: " + tmpSimDist + " chunk"));
                }
        ).dimensions(cx - bw / 2, y, bw, bh).build());
        y += gap;

        // ── Boş animasiyaları deaktiv et ────────────────────────────────────
        addToggleButton(cx, y, bw, bh, "Boş animasiyalar",
                tmpDisableIdleAnim, val -> this.tmpDisableIdleAnim = val);
        y += gap;

        // ── Gizli entity rendering ───────────────────────────────────────────
        addToggleButton(cx, y, bw, bh, "Gizli entity render",
                tmpSkipHidden, val -> this.tmpSkipHidden = val);
        y += gap;

        // ── Aqressiv yaddaş ──────────────────────────────────────────────────
        addToggleButton(cx, y, bw, bh, "Aqressiv yaddaş optim.",
                tmpAggressiveMem, val -> this.tmpAggressiveMem = val);
        y += gap + 8;

        // ── Saxla düyməsi ─────────────────────────────────────────────────────
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("✔  Saxla"),
                btn -> saveAndClose()
        ).dimensions(cx - bw / 2, y, bw / 2 - 2, bh).build());

        // ── Ləğv et düyməsi ──────────────────────────────────────────────────
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("✖  Ləğv et"),
                btn -> this.client.setScreen(parent)
        ).dimensions(cx + 2, y, bw / 2 - 2, bh).build());
    }

    // Super Opt toggle
    private void addSuperOptButton(int cx, int y, int bw, int bh) {
        ButtonWidget[] ref = new ButtonWidget[1];
        ref[0] = ButtonWidget.builder(
                superOptText(),
                btn -> {
                    tmpSuperOpt = !tmpSuperOpt;
                    btn.setMessage(superOptText());
                }
        ).dimensions(cx - bw / 2, y, bw, bh).build();
        this.addDrawableChild(ref[0]);
    }

    private Text superOptText() {
        return Text.literal("Super Optimization: " + (tmpSuperOpt ? "§aAKTİV" : "§cdeaktiv"));
    }

    // Ümumi toggle düyməsi yaradıcısı
    private void addToggleButton(int cx, int y, int bw, int bh,
                                  String label, boolean initial,
                                  java.util.function.Consumer<Boolean> onToggle) {
        boolean[] state = { initial };
        ButtonWidget[] ref = new ButtonWidget[1];
        ref[0] = ButtonWidget.builder(
                toggleText(label, state[0]),
                btn -> {
                    state[0] = !state[0];
                    onToggle.accept(state[0]);
                    btn.setMessage(toggleText(label, state[0]));
                }
        ).dimensions(cx - bw / 2, y, bw, bh).build();
        this.addDrawableChild(ref[0]);
    }

    private Text toggleText(String label, boolean on) {
        return Text.literal(label + ": " + (on ? "§aAÇIQ" : "§cQAPALI"));
    }

    private void saveAndClose() {
        config.setSuperOptimizationEnabled(tmpSuperOpt);
        config.setRenderDistance(renderDistSlider.getIntValue());
        config.setSimulationDistance(tmpSimDist);
        config.setDisableIdleAnimations(tmpDisableIdleAnim);
        config.setSkipHiddenEntityRendering(tmpSkipHidden);
        config.setAggressiveMemoryOptimization(tmpAggressiveMem);
        config.save();

        C3noxxClient.LOGGER.info("[C3noxx] Ayarlar saxlanıldı. SO={}, Render={}",
                tmpSuperOpt, renderDistSlider.getIntValue());

        this.client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Fon
        context.fill(0, 0, this.width, this.height, COLOR_BG);

        // Panel çərçivəsi
        int pw = 270, ph = 280;
        int px = this.width / 2 - pw / 2;
        int py = 40;
        context.fill(px, py, px + pw, py + ph, COLOR_PANEL);
        // Neon kənar xətt
        context.fill(px,       py,       px + pw, py + 2,      COLOR_NEON_PURPLE);
        context.fill(px,       py + ph - 2, px + pw, py + ph,  COLOR_NEON_BLUE);
        context.fill(px,       py,       px + 2,  py + ph,     COLOR_NEON_PURPLE);
        context.fill(px + pw - 2, py,   px + pw, py + ph,      COLOR_NEON_BLUE);

        // Başlıq
        String title = "[ SUPER OPTİMİZASİYA ]";
        int tw = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, this.width / 2 - tw / 2, 47, COLOR_NEON_PURPLE, false);

        // Xəbərdarlıq
        String warn = "Dəyişikliklər yenidən başladıldıqda tam aktiv olur.";
        int ww = this.textRenderer.getWidth(warn);
        context.drawText(this.textRenderer, warn, this.width / 2 - ww / 2,
                this.height - 20, COLOR_WARNING, false);

        // Tövsiyə olunan JVM
        String jvmLabel = "Tövsiyə JVM args: gradle.properties faylına bax";
        int jw = this.textRenderer.getWidth(jvmLabel);
        context.drawText(this.textRenderer, jvmLabel, this.width / 2 - jw / 2,
                this.height - 30, COLOR_LABEL, false);

        super.render(context, mouseX, mouseY, delta);
    }

    // ─── Daxili Slider Sinifləri ────────────────────────────────────────────

    private static class RenderDistanceSlider extends SliderWidget {
        private int intValue;

        RenderDistanceSlider(int x, int y, int width, int height, int initial) {
            super(x, y, width, height,
                    Text.literal("Render məsafəsi: " + initial + " chunk"),
                    (initial - 2) / 30.0);
            this.intValue = initial;
        }

        @Override
        protected void updateMessage() {
            intValue = 2 + (int)(this.value * 30);
            setMessage(Text.literal("Render məsafəsi: " + intValue + " chunk"));
        }

        @Override
        protected void applyValue() { }

        public int getIntValue() { return intValue; }
    }
}
