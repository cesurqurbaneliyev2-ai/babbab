package com.c3noxx.client.gui;

import com.c3noxx.client.C3noxxClient;
import com.c3noxx.client.config.C3noxxConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/**
 * C3noxx Nitro Ana Menyu Ekranı
 *
 * Dizayn: Qara + Neon Bənövşəyi/Mavi (Nitro estetikası)
 * Başlıq: "Azərbaycan Minecraft" (konfiqurasiyadan oxunur)
 *
 * Düymələr:
 *  - Tək Oyunçu (Singleplayer)
 *  - Çox Oyunçu (Multiplayer)
 *  - Ayarlar (Options)
 *  - Super Optimizasiya (gizli ayarlar menyusu)
 *  - Çıxış (Quit)
 */
public class C3noxxMainMenuScreen extends Screen {

    // ─── Rəng Paletası (Nitro) ──────────────────────────────────────────────
    // ARGB format: 0xAARRGGBB
    private static final int COLOR_BG_TOP        = 0xFF0A0010; // tünd qara-bənövşəyi
    private static final int COLOR_BG_BOTTOM      = 0xFF050015; // çox tünd mavi-qara
    private static final int COLOR_NEON_PURPLE    = 0xFFAA00FF; // Neon bənövşəyi
    private static final int COLOR_NEON_BLUE      = 0xFF0088FF; // Neon mavi
    private static final int COLOR_NEON_GLOW      = 0x44AA00FF; // Yarı-şəffaf parıltı
    private static final int COLOR_TEXT_PRIMARY   = 0xFFFFFFFF; // Ağ
    private static final int COLOR_TEXT_SECONDARY = 0xFFBBAADD; // Solğun bənövşəyi
    private static final int COLOR_TITLE_GRADIENT_L = 0xFFAA00FF;
    private static final int COLOR_TITLE_GRADIENT_R = 0xFF0088FF;

    // ─── Animasiya dəyişənləri ──────────────────────────────────────────────
    private float tickCounter = 0f;

    private final C3noxxConfig config;

    public C3noxxMainMenuScreen() {
        super(Text.literal("C3noxx Client"));
        this.config = C3noxxClient.INSTANCE.getConfig();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = this.height / 2 - 30;
        int btnWidth = 200;
        int btnHeight = 20;
        int gap = 24;

        // ── Tək Oyunçu ──────────────────────────────────────────────────────
        this.addDrawableChild(ButtonWidget.builder(
                Text.translatable("c3noxx.menu.singleplayer"),
                btn -> this.client.setScreen(new SelectWorldScreen(this))
        ).dimensions(centerX - btnWidth / 2, startY, btnWidth, btnHeight).build());

        // ── Çox Oyunçu ──────────────────────────────────────────────────────
        this.addDrawableChild(ButtonWidget.builder(
                Text.translatable("c3noxx.menu.multiplayer"),
                btn -> this.client.setScreen(new MultiplayerScreen(this))
        ).dimensions(centerX - btnWidth / 2, startY + gap, btnWidth, btnHeight).build());

        // ── Ayarlar ─────────────────────────────────────────────────────────
        this.addDrawableChild(ButtonWidget.builder(
                Text.translatable("c3noxx.menu.options"),
                btn -> this.client.setScreen(new OptionsScreen(this, this.client.options))
        ).dimensions(centerX - btnWidth / 2, startY + gap * 2, btnWidth, btnHeight).build());

        // ── Super Optimizasiya (Gizli Menyu) ────────────────────────────────
        this.addDrawableChild(ButtonWidget.builder(
                Text.translatable("c3noxx.menu.super_optimization"),
                btn -> this.client.setScreen(new SuperOptimizationScreen(this))
        ).dimensions(centerX - btnWidth / 2, startY + gap * 3, btnWidth, btnHeight).build());

        // ── Çıxış ───────────────────────────────────────────────────────────
        this.addDrawableChild(ButtonWidget.builder(
                Text.translatable("c3noxx.menu.quit"),
                btn -> this.client.scheduleStop()
        ).dimensions(centerX - btnWidth / 2, startY + gap * 4, btnWidth, btnHeight).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        tickCounter += delta;

        // ── 1. Nitro gradient fon ────────────────────────────────────────────
        context.fillGradient(0, 0, this.width, this.height,
                COLOR_BG_TOP, COLOR_BG_BOTTOM);

        // ── 2. Animasiyalı neon xətlər (kənarlar boyunca) ───────────────────
        if (config.isEnableBackgroundAnimation()) {
            drawNeonLines(context, delta);
        }

        // ── 3. Mərkəzdəki "C3NOXX" loqo başlığı ────────────────────────────
        if (config.isShowNitroLogo()) {
            drawNitroLogo(context);
        }

        // ── 4. Alt başlıq (Azərbaycan Minecraft) ────────────────────────────
        String subTitle = config.getMainMenuTitle();
        int subW = this.textRenderer.getWidth(subTitle);
        context.drawText(this.textRenderer, subTitle,
                this.width / 2 - subW / 2,
                this.height / 2 - 70,
                COLOR_TEXT_SECONDARY, false);

        // ── 5. Versiyon etiketi ──────────────────────────────────────────────
        String versionTag = "C3noxx Client v1.0.0 | MC 1.21.1 | Fabric";
        context.drawText(this.textRenderer, versionTag, 4, this.height - 10,
                0x88AAAAAA, false);

        // ── 6. Düymələr ──────────────────────────────────────────────────────
        super.render(context, mouseX, mouseY, delta);
    }

    /**
     * Animasiyalı neon kənar xətlər — parıldayan xəttlər ekranın 4 kənarında
     */
    private void drawNeonLines(DrawContext context, float delta) {
        float pulse = (float)(Math.sin(tickCounter * 0.05f) * 0.5f + 0.5f); // 0..1
        int alpha = (int)(80 + pulse * 120); // 80..200
        int lineColor = (alpha << 24) | 0x00AA00FF; // neon bənövşəyi, pulsing alpha

        // Üst xətt
        context.fill(0, 0, this.width, 2, lineColor);
        // Alt xətt
        context.fill(0, this.height - 2, this.width, this.height, lineColor);
        // Sol xətt
        context.fill(0, 0, 2, this.height, lineColor);
        // Sağ xətt
        context.fill(this.width - 2, 0, this.width, this.height, lineColor);

        // Köşe parıltıları
        int glowSize = 60;
        context.fillGradient(0, 0, glowSize, glowSize, (alpha / 2 << 24) | 0x00AA00FF, 0x00000000);
        context.fillGradient(this.width - glowSize, 0, this.width, glowSize, (alpha / 2 << 24) | 0x000088FF, 0x00000000);
    }

    /**
     * "C3NOXX" mətn loqosunu gradient ilə çəkir
     */
    private void drawNitroLogo(DrawContext context) {
        String logo = "C3NOXX";
        // Böyük miqyas üçün iki dəfə render et (kölgə + əsas)
        int logoX = this.width / 2 - (this.textRenderer.getWidth(logo) * 2) / 2;
        int logoY = this.height / 2 - 105;

        // Kölgə (parıltı effekti)
        context.getMatrices().push();
        context.getMatrices().scale(2.0f, 2.0f, 1.0f);
        context.drawText(this.textRenderer, logo,
                logoX / 2 + 1, logoY / 2 + 1,
                0x66000000, false);

        // Sol yarı — neon bənövşəyi
        context.drawText(this.textRenderer, "C3N",
                logoX / 2, logoY / 2,
                COLOR_NEON_PURPLE, false);

        // Sağ yarı — neon mavi
        int halfWidth = this.textRenderer.getWidth("C3N") * 2;
        context.drawText(this.textRenderer, "OXX",
                logoX / 2 + this.textRenderer.getWidth("C3N"), logoY / 2,
                COLOR_NEON_BLUE, false);

        context.getMatrices().pop();

        // "CLIENT" alt yazısı
        String clientLabel = "CLIENT";
        int clW = this.textRenderer.getWidth(clientLabel);
        context.drawText(this.textRenderer, clientLabel,
                this.width / 2 - clW / 2,
                logoY + 22,
                COLOR_TEXT_SECONDARY, false);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
