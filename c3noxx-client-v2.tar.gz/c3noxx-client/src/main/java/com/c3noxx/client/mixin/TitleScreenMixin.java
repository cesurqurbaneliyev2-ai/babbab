package com.c3noxx.client.mixin;

import com.c3noxx.client.C3noxxClient;
import com.c3noxx.client.gui.C3noxxMainMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * TitleScreenMixin — Ana Menyu Mixin Sinifi
 *
 * Bu Mixin, Minecraft-in standart TitleScreen-ni tutaraq
 * C3noxx Nitro dizaynlı ana menyusuna yönləndirir.
 *
 * Necə işləyir:
 *  1. TitleScreen#init() çağırıldıqda Mixin devreye girir.
 *  2. Əgər C3noxx loqo/Nitro GUI aktiv isə, C3noxxMainMenuScreen açılır.
 *  3. Orijinal init() ləğv edilir (CallbackInfo#cancel).
 */
@Mixin(TitleScreen.class)
public class TitleScreenMixin {

    /**
     * TitleScreen#init() metoduna HEAD nöqtəsindən inject edirik.
     * Bu, standart GUI elementləri render edilməzdən əvvəl baş verir.
     */
    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void c3noxx$replaceTitleScreen(CallbackInfo ci) {
        // Yalnız C3noxx modu tam yüklənibsə dəyiş
        if (C3noxxClient.INSTANCE == null) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return;

        // Orijinal TitleScreen-i C3noxx Nitro GUI ilə əvəz et
        mc.setScreen(new C3noxxMainMenuScreen());

        // Orijinal init() dayandır — bizim ekranımız öz init-ini çağıracaq
        ci.cancel();
    }
}
